## Proveably a Random Raffle Contracts

## About

This code in this directory is to create a proveably random smart contract lottery.

## WHat we want it to do it?

1) Users can enter by paying for a ticket
   -The ticket fees are going to go to the winner of this lottery during the draw
2) After X period of time, the lottery will automatically draw a winner
   -And this will be done programatically
3) Using Chainlink VRF and Chainlink Automation
   -Chainlink VRF --> Randomness
   -Chainlink Automation --> Time based trigger

## Tests!!
1. Write some deploy scripts
2. Write our tests
   1. Work on a local chain
   2. Forked Testnet
   3. Forked Mainnet